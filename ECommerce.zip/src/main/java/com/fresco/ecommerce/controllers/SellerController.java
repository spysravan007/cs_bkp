package com.fresco.ecommerce.controllers;

import java.net.URI;
import java.security.Principal;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.fresco.ecommerce.models.Product;
import com.fresco.ecommerce.models.User;
import com.fresco.ecommerce.repo.CategoryRepo;
import com.fresco.ecommerce.repo.ProductRepo;
import com.fresco.ecommerce.repo.UserRepo;

@RestController
@RequestMapping("/api/auth/seller")
public class SellerController {
	@Autowired
	ProductRepo productRepo;
	@Autowired
	UserRepo userRepo;
	@Autowired
	CategoryRepo categoryRepo;

	@PostMapping("/product")
	public ResponseEntity<Object> postProduct(Principal principal, @RequestBody Product product) {
		product.setProductId(-1);
		product.setSeller(userRepo.findByUsername(principal.getName()).get());
		product.setCategory(categoryRepo.findByCategoryName(product.getCategory().getCategoryName()).get());
		product = productRepo.save(product);
		URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{productId}")
				.buildAndExpand(product.getProductId()).toUri();
		return ResponseEntity.created(location).build();
	}

	@GetMapping("/product")
	public ResponseEntity<Object> getAllProducts(Principal principal) {
		return ResponseEntity.ok(productRepo.findBySellerUserId(
				((User) SecurityContextHolder.getContext().getAuthentication().getPrincipal()).getUserId()));
	}

	@GetMapping("/product/{productId}")
	public ResponseEntity<Object> getProduct(Principal principal, @PathVariable Integer productId) {
		Optional<Product> product = productRepo.findBySellerUserIdAndProductId(
				((User) SecurityContextHolder.getContext().getAuthentication().getPrincipal()).getUserId(), productId);
		if (product.isPresent())
			return ResponseEntity.ok(product.get());
		else
			return ResponseEntity.notFound().build();
	}

	@PutMapping("/product")
	public ResponseEntity<Object> putProduct(Principal principal, @RequestBody Product updatedProduct) {
		Optional<Product> product = productRepo.findBySellerUserIdAndProductId(
				((User) SecurityContextHolder.getContext().getAuthentication().getPrincipal()).getUserId(),
				updatedProduct.getProductId());
		if (product.isPresent()) {
			product.get()
					.setCategory(categoryRepo.findByCategoryName(updatedProduct.getCategory().getCategoryName()).get());
			product.get().setPrice(updatedProduct.getPrice());
			product.get().setProductName(updatedProduct.getProductName());
			updatedProduct = productRepo.save(product.get());
			return ResponseEntity.ok().body(updatedProduct);
		} else {
			return ResponseEntity.notFound().build();
		}
	}

	@DeleteMapping("/product/{productId}")
	public ResponseEntity<Product> deleteProduct(Principal principal, @PathVariable Integer productId) {
		Optional<Product> product = productRepo.findBySellerUserIdAndProductId(
				((User) SecurityContextHolder.getContext().getAuthentication().getPrincipal()).getUserId(), productId);
		if (product.isPresent()) {
			productRepo.deleteById(productId);
			return ResponseEntity.ok().body(product.get());
		} else {
			return ResponseEntity.notFound().build();
		}
	}
}