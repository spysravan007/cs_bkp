package com.fresco.ecommerce.config;

import java.util.Date;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;

import com.fresco.ecommerce.models.User;
import com.fresco.ecommerce.repo.UserRepo;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

@Component
public class JwtUtil {
	@Value("${jwt.secret}")
	private String jwtSecret;
	@Value("${jwt.token.validity}")
	private long tokenValidity;
	@Autowired
	UserRepo userRepo;

	public User getUser(final String token) {
		Claims body = Jwts.parser().setSigningKey(jwtSecret).parseClaimsJws(token).getBody();
		Optional<User> user = userRepo.findByUsername(body.getSubject());
		if(!user.isPresent())
			throw new UsernameNotFoundException("UserID not found");
		return user.get();
	}

	public String generateToken(String username) {
		Claims claims = Jwts.claims().setSubject(username);
		long nowMillis = System.currentTimeMillis();
		long expMillis = nowMillis + tokenValidity;
		Date exp = new Date(expMillis);
		return Jwts.builder().setClaims(claims).setIssuedAt(new Date(nowMillis)).setExpiration(exp)
				.signWith(SignatureAlgorithm.HS512, jwtSecret).compact();
	}

	public void validateToken(final String token) {
		Jwts.parser().setSigningKey(jwtSecret).parseClaimsJws(token);
	}
}
