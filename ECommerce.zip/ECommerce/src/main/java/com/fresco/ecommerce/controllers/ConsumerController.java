package com.fresco.ecommerce.controllers;

import java.security.Principal;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fresco.ecommerce.models.Cart;
import com.fresco.ecommerce.models.CartProduct;
import com.fresco.ecommerce.models.Product;
import com.fresco.ecommerce.models.User;
import com.fresco.ecommerce.repo.CartProductRepo;
import com.fresco.ecommerce.repo.CartRepo;
import com.fresco.ecommerce.repo.ProductRepo;
import com.fresco.ecommerce.repo.UserRepo;

@RestController
@RequestMapping("/api/auth/consumer")
public class ConsumerController {
	@Autowired
	ProductRepo productRepo;
	@Autowired
	CartRepo cartRepo;
	@Autowired
	CartProductRepo cpRepo;
	@Autowired
	UserRepo userRepo;

	@GetMapping("/cart")
	public ResponseEntity<Object> getCart(Principal principal) {
		return ResponseEntity.ok(cartRepo.findByUserUsername(principal.getName()).get());
	}

	@PostMapping("/cart")
	public ResponseEntity<Object> postCart(Principal principal, @RequestBody Product product) {
		Optional<Product> dbProduct = productRepo.findById(product.getProductId());
		if (!dbProduct.isPresent())
			return ResponseEntity.badRequest().build();
		Cart cart = cartRepo.findByUserUsername(principal.getName()).get();
		if (cart.getCartProducts().stream()
				.anyMatch(cp -> cp.getProduct().getProductId() == dbProduct.get().getProductId()))
			return ResponseEntity.status(HttpStatus.CONFLICT).build();
		cart.updateTotalAmount(dbProduct.get().getPrice());
		cpRepo.save(new CartProduct(cart, dbProduct.get(), 1));
		cartRepo.save(cart);
		return ResponseEntity.ok().build();
	}

	@PutMapping("/cart")
	public ResponseEntity<Object> putCart(Principal principal, @RequestBody CartProduct cp) {
		if (cp.getQuantity() <= 0)
			return deleteCart(principal, cp.getProduct());
		Optional<Product> product = productRepo.findById(cp.getProduct().getProductId());
		if (!product.isPresent())
			return ResponseEntity.badRequest().build();
		Cart cart = cartRepo.findByUserUsername(principal.getName()).get();
		Optional<CartProduct> oCP = cart.getCartProducts().stream()
				.filter(x -> x.getProduct().getProductId() == product.get().getProductId()).findFirst();
		if (oCP.isPresent()) {
			cart.updateTotalAmount((cp.getQuantity() - oCP.get().getQuantity()) * product.get().getPrice());
		} else {
			cart.updateTotalAmount(product.get().getPrice());
			oCP = Optional.of(new CartProduct(cart, product.get(), cp.getQuantity()));
		}
		oCP.get().setQuantity(cp.getQuantity());
		cpRepo.save(oCP.get());
		cartRepo.save(cart);
		return ResponseEntity.ok().build();
	}

	@DeleteMapping("/cart")
	public ResponseEntity<Object> deleteCart(Principal principal, @RequestBody Product product) {
		Optional<Product> eProduct = productRepo.findById(product.getProductId());
		if (!eProduct.isPresent())
			return ResponseEntity.badRequest().build();
		Cart cart = cartRepo.findByUserUsername(principal.getName()).get();

		Optional<CartProduct> cp = cart.getCartProducts().stream()
				.filter(x -> x.getProduct().getProductId() == eProduct.get().getProductId()).findFirst();
		if (cp.isPresent()) {
			cart.updateTotalAmount(cp.get().getQuantity() * cp.get().getProduct().getPrice() * -1);
			cpRepo.deleteByCartUserUserIdAndProductProductId(
					((User) SecurityContextHolder.getContext().getAuthentication().getPrincipal()).getUserId(),
					product.getProductId());
			cart.getCartProducts().remove(cp.get());
			cartRepo.save(cart);
		}
		return ResponseEntity.ok().build();
	}

}